export const filterData = [
  "Empresa",
  "Icone",
  "Nome",
  "Convidados",
  "Criado em",
  "Ações",
];

export const users = [
  {
    name: "User 01",
    email: "user@hotmail.com",
    telefone: "2199999999",
    status: "pendente",
    createAt: "16/06/2024",
  },
];

export const infos = {
  users: 405,
  places: 10,
  reservation: 0,
  points: 0,
};
