import { ReactNode } from "react"

export interface IBannerProps {
    children: ReactNode 
    id: string 
    className: string
}