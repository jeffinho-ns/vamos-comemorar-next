export default function AdminTemplate({ children } : { children: React.ReactNode }) {
    return (
        <>
            {children}
        </>
    )
} 